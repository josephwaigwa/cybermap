# Cyber-threat-map

A simulation of a live cyber threat map.
The app relies on random data that is generated continuously.
The app also uses an external API which helps analyzing the different IP addresses.

Was build on a local server, check out the 'download instructions' file in order to learn how to upload it.

credit to: https://github.com/hrbrmstr/pewpew
